# Lidl PLU Trainer (Android-Widget)

Ein kleines natives Android-Projekt mit Homescreen-Widget und Multiple-Choice-PLU-Quiz.

## Öffnen und bauen
1. Android Studio installieren.
2. Dieses Projekt entpacken und den Ordner `LidlPLUWidget` in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. Ein Android-Gerät per USB verbinden oder einen Emulator starten.
5. `Run` drücken. Alternativ: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Widget hinzufügen (Samsung)
Startbildschirm lange drücken > Widgets > Lidl PLU Trainer > Widget gedrückt halten und auf den Startbildschirm ziehen.

## Lernliste ändern
Datei: `app/src/main/java/de/lidlplu/widget/PluQuestion.kt`
Weitere Einträge im Format `PluQuestion("Produkt", 123, "Kategorie")` ergänzen.

## Wichtiger Hinweis
Die mitgelieferten Nummern sind nur vorläufige Beispielwerte aus der vorherigen Unterhaltung. Sie sind keine offiziell bestätigte oder vollständige Lidl-PLU-Liste. Vor echtem Einsatz bitte mit den PLU-Zuordnungen deiner Filiale abgleichen.
