package de.lidlplu.widget

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.WHITE)
        }
        fun add(text: String, size: Float, color: Int = Color.DKGRAY, bold: Boolean = false) {
            layout.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.START
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            })
        }
        add("Lidl PLU Trainer", 26f, Color.rgb(23, 107, 58), true)
        add("Widget hinzufügen", 19f, Color.BLACK, true)
        add("1. Halte eine freie Stelle auf deinem Startbildschirm gedrückt.", 16f)
        add("2. Tippe auf „Widgets“.", 16f)
        add("3. Suche „Lidl PLU Trainer“ und ziehe das Widget auf den Homescreen.", 16f)
        add("Hinweis zur Lernliste", 19f, Color.BLACK, true)
        add("Die enthaltenen PLU-Nummern sind vorläufige Beispielwerte aus der bisherigen Unterhaltung und keine bestätigte offizielle Lidl-Liste. Bitte prüfe sie vor dem Lernen im Markt.", 14f)
        add("Die Fragen wechseln direkt im Widget. Tippe eine Antwort an und anschließend auf „Nächste Frage“.", 14f)
        setContentView(layout)
    }
}
