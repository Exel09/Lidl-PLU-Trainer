package de.lidlplu.widget

data class PluQuestion(val name: String, val plu: Int, val category: String)

object PluData {
    // Beispiel-Lernwerte aus der bisherigen Unterhaltung.
    // Vor dem Lernen im Markt/Kassensystem gegenprüfen: keine offizielle Lidl-Gesamtliste.
    val questions = listOf(
        PluQuestion("Bananen", 55, "Obst"),
        PluQuestion("Bio-Bananen", 45, "Obst"),
        PluQuestion("Ananas", 620, "Obst"),
        PluQuestion("Avocado", 621, "Obst"),
        PluQuestion("Kiwi", 624, "Obst"),
        PluQuestion("Mango", 627, "Obst"),
        PluQuestion("Zitronen", 612, "Obst"),
        PluQuestion("Limetten", 601, "Obst"),
        PluQuestion("Erdbeeren 250 g", 770, "Obst"),
        PluQuestion("Wassermelone", 79, "Obst"),
        PluQuestion("Auberginen", 90, "Gemüse"),
        PluQuestion("Brokkoli", 206, "Gemüse"),
        PluQuestion("Blumenkohl", 200, "Gemüse"),
        PluQuestion("Gurken", 310, "Gemüse"),
        PluQuestion("Zucchini", 93, "Gemüse"),
        PluQuestion("Paprika rot", 66, "Gemüse"),
        PluQuestion("Möhren", 211, "Gemüse"),
        PluQuestion("Knoblauch", 141, "Gemüse"),
        PluQuestion("Radieschen", 150, "Gemüse"),
        PluQuestion("Champignons weiß", 341, "Gemüse"),
        PluQuestion("Süßkartoffeln", 25, "Gemüse"),
        PluQuestion("Buttercroissant", 878, "Backwaren"),
        PluQuestion("Laugenbrezel", 891, "Backwaren"),
        PluQuestion("Baguette", 894, "Backwaren"),
        PluQuestion("Weizenbrötchen", 880, "Backwaren")
    )
}
