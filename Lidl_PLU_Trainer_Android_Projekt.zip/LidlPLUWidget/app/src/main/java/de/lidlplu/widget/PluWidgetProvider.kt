package de.lidlplu.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.random.Random

class PluWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!prefs.contains(key(id, "question"))) newQuestion(context, id)
            render(context, manager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        when (intent.action) {
            ACTION_ANSWER -> {
                val selected = intent.getIntExtra("selected", -1)
                val correct = prefs(context).getInt(key(id, "answer"), -2)
                prefs(context).edit()
                    .putBoolean(key(id, "answered"), true)
                    .putBoolean(key(id, "correct"), selected == correct)
                    .apply()
                render(context, AppWidgetManager.getInstance(context), id)
            }
            ACTION_NEXT -> {
                newQuestion(context, id)
                render(context, AppWidgetManager.getInstance(context), id)
            }
        }
    }

    private fun newQuestion(context: Context, id: Int) {
        val q = PluData.questions.random()
        val wrong = PluData.questions.filter { it.plu != q.plu }.map { it.plu }.distinct().shuffled().take(2)
        val options = (wrong + q.plu).shuffled()
        prefs(context).edit()
            .putString(key(id, "question"), q.name)
            .putString(key(id, "category"), q.category)
            .putInt(key(id, "answer"), q.plu)
            .putInt(key(id, "o1"), options[0])
            .putInt(key(id, "o2"), options[1])
            .putInt(key(id, "o3"), options[2])
            .putBoolean(key(id, "answered"), false)
            .putBoolean(key(id, "correct"), false)
            .apply()
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val p = prefs(context)
        val views = RemoteViews(context.packageName, R.layout.plu_widget)
        val name = p.getString(key(id, "question"), "PLU-Frage") ?: "PLU-Frage"
        val category = p.getString(key(id, "category"), "") ?: ""
        val answer = p.getInt(key(id, "answer"), -1)
        val answered = p.getBoolean(key(id, "answered"), false)
        views.setTextViewText(R.id.product_name, name)
        views.setTextViewText(R.id.question_text, "$category • Welche PLU hat dieses Produkt?")
        val optionIds = intArrayOf(R.id.option_1, R.id.option_2, R.id.option_3)
        val values = intArrayOf(p.getInt(key(id, "o1"), 0), p.getInt(key(id, "o2"), 0), p.getInt(key(id, "o3"), 0))
        optionIds.forEachIndexed { index, viewId ->
            views.setTextViewText(viewId, values[index].toString())
            views.setOnClickPendingIntent(viewId, if (answered) null else answerPendingIntent(context, id, values[index], index))
        }
        if (answered) {
            val correct = p.getBoolean(key(id, "correct"), false)
            views.setTextViewText(R.id.feedback, if (correct) "✓ Richtig! PLU $answer" else "✗ Richtig wäre: $answer")
            views.setTextViewText(R.id.next_button, "Nächste Frage →")
        } else {
            views.setTextViewText(R.id.feedback, "Wähle die richtige PLU-Nummer.")
            views.setTextViewText(R.id.next_button, "Überspringen / nächste →")
        }
        val next = Intent(context, PluWidgetProvider::class.java).apply {
            action = ACTION_NEXT
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        }
        views.setOnClickPendingIntent(R.id.next_button, PendingIntent.getBroadcast(
            context, id * 10 + 9, next, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        ))
        manager.updateAppWidget(id, views)
    }

    private fun answerPendingIntent(context: Context, id: Int, value: Int, index: Int): PendingIntent {
        val intent = Intent(context, PluWidgetProvider::class.java).apply {
            action = ACTION_ANSWER
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            putExtra("selected", value)
        }
        return PendingIntent.getBroadcast(
            context, id * 10 + index, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        private const val PREFS = "plu_widget"
        private const val ACTION_ANSWER = "de.lidlplu.widget.ANSWER"
        private const val ACTION_NEXT = "de.lidlplu.widget.NEXT"
        private fun key(id: Int, field: String) = "${id}_$field"
        private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }
}
