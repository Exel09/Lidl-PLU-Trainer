plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.lidlplu.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.lidlplu.widget"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
